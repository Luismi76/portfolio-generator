import React, { useState } from "react";
import { Icons } from "../portfolio-icons";
import { usePortfolioData, useDataExport } from "../portfolio-hooks";
import { downloadFile, createTemplateAwareExporter } from "../portfolio-export";
import { PersonalInfoForm } from "../PersonalInfoForm";
import ProjectTableForm from "../ProjectTableForm";
import SkillTableForm from "../SkillTableForm";
import { useTemplates } from "../use-templates";
import { AdvancedTemplateSelector } from "../AdvancedTemplateSelector";
import { AdvancedTemplate } from "../../types/advanced-template-types";
import { ADVANCED_BUILT_IN_TEMPLATES } from "../advanced-built-in-templates";
//import { Section } from '../../types/advanced-template-types';

const ModernPortfolioEditor: React.FC = () => {
  const {
    data,
    updatePersonalInfo,
    updateProject,
    updateSkill,
    addItem,
    removeItem,
    importData,
  } = usePortfolioData();
  const { exportToJSON, importFromJSON } = useDataExport();
  const [activeSection, setActiveSection] = useState<
    "personal" | "projects" | "skills" | "templates"
  >("personal");
  const [showExportMenu, setShowExportMenu] = useState(false);

  // ✅ Obtener templates con mejor debugging
  const { selectedTemplate, config, updateConfig } = useTemplates();
  const activeTemplate: any =
    selectedTemplate ?? ADVANCED_BUILT_IN_TEMPLATES[0];
  // Convertir Template simple a AdvancedTemplate

  const handleExportJSON = () => {
    exportToJSON(data);
  };

  const handleImportJSON = () => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".json,application/json";
    input.onchange = async (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (!file) return;

      const result = await importFromJSON(file);
      if (result.success && result.data) {
        importData(result.data);
        alert("Datos importados correctamente");
        window.location.reload();
      } else {
        alert("Error al importar: " + result.message);
      }
    };
    input.click();
  };

  // ✅ FUNCIÓN CORREGIDA con debugging completo
  const handleExportHTML = () => {
    console.log("🔍 DEBUG - Estado actual:");
    console.log("- selectedTemplate:", selectedTemplate?.name);
    console.log("- activeTemplate:", activeTemplate?.name);
    console.log("- config:", config);
    console.log(
      "- config?.customizations?.sections:",
      config?.customizations?.sections
    );

    if (config?.customizations?.sections) {
      console.log("📋 Secciones personalizadas:");
      config.customizations.sections.forEach((section) => {
        console.log(
          `  ${section.id}: ${section.enabled ? "HABILITADA" : "DESHABILITADA"}`
        );
      });
    } else {
      console.log("⚠️ No hay secciones personalizadas, usando plantilla base");
      if (activeTemplate?.sections) {
        console.log("📋 Secciones de plantilla base:");
        activeTemplate.sections.forEach((section: any) => {
          console.log(
            `  ${section.id}: ${
              section.enabled ? "HABILITADA" : "DESHABILITADA"
            }`
          );
        });
      }
    }

    try {
      const exporter = createTemplateAwareExporter(
        data,
        activeTemplate,
        "single",
        config || undefined
      );
      const res = exporter.export();

      console.log("✅ Resultado de exportación:", res);
      alert(res.message);
    } catch (e: any) {
      console.error("❌ Error en exportación:", e);
      alert("Error al exportar HTML: " + (e?.message || e));
    }
  };

  // ✅ FUNCIÓN CORREGIDA con debugging completo
  const handleExportWebsite = () => {
    console.log("🔍 DEBUG - Estado actual:");
    console.log("- selectedTemplate:", selectedTemplate?.name);
    console.log("- activeTemplate:", activeTemplate?.name);
    console.log("- config:", config);
    console.log(
      "- config?.customizations?.sections:",
      config?.customizations?.sections
    );

    if (config?.customizations?.sections) {
      console.log("📋 Secciones personalizadas:");
      config.customizations.sections.forEach((section) => {
        console.log(
          `  ${section.id}: ${section.enabled ? "HABILITADA" : "DESHABILITADA"}`
        );
      });
    } else {
      console.log("⚠️ No hay secciones personalizadas, usando plantilla base");
      if (activeTemplate?.sections) {
        console.log("📋 Secciones de plantilla base:");
        activeTemplate.sections.forEach((section: any) => {
          console.log(
            `  ${section.id}: ${
              section.enabled ? "HABILITADA" : "DESHABILITADA"
            }`
          );
        });
      }
    }

    try {
      const exporter = createTemplateAwareExporter(
        data,
        activeTemplate,
        "multi",
        config || undefined
      );

      const res = exporter.export();
      console.log("✅ Resultado de exportación:", res);

      if (!res.success) {
        alert(res.message);
        return;
      }

      if ("files" in res && (res as any).files) {
        const files = (res as any).files as Record<string, string>;
        const entries = Object.entries(files);

        if (entries.length === 0) {
          alert(`${res.message}\nNo se recibieron archivos para descargar.`);
          return;
        }

        entries.forEach(([filename, content], idx) => {
          setTimeout(() => downloadFile(filename, content), idx * 600);
        });

        alert(`${res.message}\nSe han generado ${entries.length} archivos.`);
      } else {
        alert(
          `${res.message}\nEl exportador actual no expone 'files'. Usa "Exportar HTML" (single) o actualiza el exportador para devolver { files } en modo "multi".`
        );
      }
    } catch (e: any) {
      console.error("❌ Error en exportación:", e);
      alert("Error al exportar sitio: " + (e?.message || e));
    }
  };

  // Añade estas funciones DENTRO del componente, después de handleExportWebsite

  const handleDuplicateTemplate = (template: AdvancedTemplate) => {
    const newName = prompt(
      `Duplicar "${template.name}" como:`,
      `${template.name} (Copia)`
    );
    if (newName) {
      alert(
        `Plantilla "${newName}" duplicada (por implementar en useTemplates)`
      );
    }
  };

  const handleExportTemplate = (template: AdvancedTemplate) => {
    const json = JSON.stringify(template, null, 2);
    const blob = new Blob([json], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `template-${template.name
      .toLowerCase()
      .replace(/\s+/g, "-")}.json`;
    link.click();
    URL.revokeObjectURL(url);
    alert(`✓ Plantilla "${template.name}" exportada`);
  };

  const handleDeleteTemplate = (template: AdvancedTemplate) => {
    if (template.isBuiltIn) {
      alert("No puedes eliminar plantillas predefinidas");
      return;
    }
    if (window.confirm(`¿Eliminar plantilla "${template.name}"?`)) {
      alert("Eliminar plantilla (por implementar en useTemplates)");
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-gray-900">
          Editor de Portfolio
        </h1>
        <div className="relative">
          <button
            onClick={() => setShowExportMenu(!showExportMenu)}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 flex items-center gap-2"
          >
            <Icons.Download size={16} />
            Exportar
            <Icons.ChevronDown size={16} />
          </button>

          {showExportMenu && (
            <div className="absolute right-0 top-full mt-2 w-56 bg-white rounded-lg shadow-lg border z-50">
              <button
                onClick={() => {
                  handleExportJSON();
                  setShowExportMenu(false);
                }}
                className="w-full text-left px-4 py-2 hover:bg-gray-100 flex items-center gap-2"
              >
                <Icons.FileDown size={16} />
                Exportar JSON
              </button>
              <button
                onClick={() => {
                  handleExportHTML();
                  setShowExportMenu(false);
                }}
                className="w-full text-left px-4 py-2 hover:bg-gray-100 flex items-center gap-2"
              >
                <Icons.Download size={16} />
                Exportar HTML
              </button>
              <button
                onClick={() => {
                  handleExportWebsite();
                  setShowExportMenu(false);
                }}
                className="w-full text-left px-4 py-2 hover:bg-gray-100 flex items-center gap-2"
              >
                <Icons.ExternalLink size={16} />
                Sitio Web + GitHub Pages
              </button>
              <hr className="my-1" />
              <button
                onClick={() => {
                  handleImportJSON();
                  setShowExportMenu(false);
                }}
                className="w-full text-left px-4 py-2 hover:bg-gray-100 flex items-center gap-2"
              >
                <Icons.Upload size={16} />
                Importar JSON
              </button>
            </div>
          )}
        </div>
      </div>

      <div className="flex space-x-1 mb-6 bg-gray-100 p-1 rounded-lg">
        {[
          { id: "personal" as const, label: "Personal", icon: Icons.User },
          { id: "projects" as const, label: "Proyectos", icon: Icons.Code },
          { id: "skills" as const, label: "Habilidades", icon: Icons.Award },
          {
            id: "templates" as const,
            label: "Plantillas",
            icon: Icons.Settings,
          },
        ].map((section) => (
          <button
            key={section.id}
            onClick={() => setActiveSection(section.id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-colors ${
              activeSection === section.id
                ? "bg-white text-blue-600 shadow-sm"
                : "text-gray-600 hover:text-gray-900"
            }`}
          >
            <section.icon size={16} />
            {section.label}
          </button>
        ))}
      </div>

      <div className="space-y-6">
        {activeSection === "personal" && (
          <PersonalInfoForm
            data={data.personalInfo}
            onUpdate={updatePersonalInfo}
          />
        )}

        {activeSection === "projects" && (
          <ProjectTableForm
            projects={data.projects}
            onUpdate={updateProject}
            onAdd={() => addItem("projects")}
            onRemove={(index) => removeItem("projects", index)}
          />
        )}

        {activeSection === "skills" && (
          <SkillTableForm
            skills={data.skills}
            onUpdate={updateSkill}
            onAdd={() => addItem("skills")}
            onRemove={(index) => removeItem("skills", index)}
          />
        )}

        {activeSection === "templates" && (
          <AdvancedTemplateSelector
            templates={ADVANCED_BUILT_IN_TEMPLATES} // <-- USA LAS PLANTILLAS REALES
            selectedTemplate={ADVANCED_BUILT_IN_TEMPLATES[0]}
            onTemplateSelect={(advTemplate) => {
              // Simplemente actualizar con el ID de la plantilla avanzada
              if (updateConfig) {
                updateConfig({ templateId: advTemplate.id });
              }
              console.log("Plantilla seleccionada:", advTemplate.name);
            }}
            onCustomize={(template) => {
              window.alert(
                `Personalizar "${template.name}" - Editor visual por implementar`
              );
            }}
            onPreview={(template) => {
              window.alert(
                `Vista previa de "${template.name}" - Por implementar`
              );
            }}
            onDuplicate={handleDuplicateTemplate}
            onExport={handleExportTemplate}
            onDelete={handleDeleteTemplate}
          />
        )}
      </div>
    </div>
  );
};

export default ModernPortfolioEditor;
